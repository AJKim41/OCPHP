		<div class="col-md-12" style="padding-top: 55px; padding-bottom: 25px;">
			<div id="headerLogo" class="row">
				<div class="col-md-6">
                     <img id="logo" src="img/logo.jpeg">
				</div>
				<div class="col-md-6">
					<ul id="navBar2" class="nav nav-pills">
						<li>
							<a href="index.php">Home</a>
						</li>
						<li>
							<a href="about.php">About</a>
						</li>
						<li>
							<a href="product.php">Product</a>
						</li>
                    </ul>
                </div>
			</div>
        </div>