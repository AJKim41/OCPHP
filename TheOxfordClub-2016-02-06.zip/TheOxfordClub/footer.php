<footer>       
	<div class="row" id="footerList">
		<div class="col-md-3">
            <br>
            <center id="footerHeader" class="footerHeader">News Letter</center>
            
        <ul>
            <li><a href="#">The Oxford Communiqué</a></li>
            <li><a href="#">The Oxford Income Letter</a></li>
            <li><a href="#">Oxford Resource Explorer</a></li>
        </ul>
		</div>
		<div class="col-md-3">
            <br>
            <center id="footerHeader" class="footerHeader">Trading Services</center>
            
        <ul>
            <li><a href="#">Advanced Energy Strategist</a></li>
            <li><a href="#">Prime System Trader</a></li>
            <li><a href="#">Lightning Trend Trader</a></li>
            <li><a href="#">Oxford Bond Advantage</a></li>
            <li><a href="#">Oxford Systems Trader</a></li>
        </ul>
		</div>
		<div class="col-md-2">
            <br><br>
        <ul>
            <li><a href="#">The Insider Alert</a></li>
            <li><a href="#">The Momentum Alert</a></li>
            <li><a href="#">The True Value Alert</a></li>
            <li><a href="#">The VIPER Alert</a></li>
        </ul>
		</div>
		<div class="col-md-2">
           <br>
            <center class="footerHeader">Premium E-Letters</center>
        <ul>
            <li><a href="#">Investment U Plus</a></li>
            <li><a href="#">SafetyNet Pro</a></li>
        </ul>
            <center class="footerHeader">On The Air</center>
        <ul>
            <li><a href="#">Oxford Radio</a></li>
        </ul>
		</div>
		<div class="col-md-2">
          <br>
            <center class="footerHeader">Our Free Offerings</center>
            
        <ul>
            <li><a href="#">Investment U</a></li>
            <li><a href="#">Wealthy Retirement</a></li>
            <li><a href="#">Energy &amp; Resources</a></li>
            <li><a href="#">Beyond Wealth</a></li>
        </ul>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12" style="padding-top: 2em;">
            <center><img src="img/logo.jpeg"></center>
            <center><p>
                The Oxford Club, LLC
                <br>
                105 W. Monument Street, Baltimore, MD 21201
                <br>
                Phone: 866-237-0436 | Int'l Phone: 443-353-4540
            </p></center>
            <div class="footerNav">
                <center>
                <li><a href="about.php">About</a></li>
                <li><a href="#">Contact Us</a></li>
                <li><a href="#">Whitelist Instructions</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Disclaimer</a></li>
                <li><a href="#">Everbank Disclaimer</a></li>
                <li><a href="#">Careers</a></li>
                </center>
            </div>
		</div>
	</div>
</footer>