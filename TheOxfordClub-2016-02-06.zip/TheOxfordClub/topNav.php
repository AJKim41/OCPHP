<div class="col-md-12">
			<nav class="navbar navbar-default navbar-inverse navbar-fixed-top" role="navigation">
			
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav" id="navbarLocked">
                        <li>
							<a href="#">The Oxford Club</a>
						</li>
						<li>
							<a href="#">Investment U</a>
						</li>
						<li>
							<a href="#">Wealthy Retirement</a>
						</li>
                        <li>
							<a href="#">Energy &amp; Resource Digest</a>
						</li>
                        <li>
							<a href="#">Bookstore</a>
						</li>
						
					</ul>
				</div>
             </nav>